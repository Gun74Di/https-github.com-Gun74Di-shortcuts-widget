# Shortcuts Widget x Zama FHE

This is a simple demo project for the **Zama Builder Track Submission - September**.

## Features
- 🔐 FHE-powered secure computations
- ⚡ Simple shortcut-based interactions
- 🌐 Deployed on Vercel

## Links
- GitHub Repo: https://github.com/Gun74Di/shortcuts-widget
- Live Demo: https://shortcuts-widget-gun74dis-projects.vercel.app
- X (Twitter): [@adijayaguna_p](https://x.com/adijayaguna_p)

---
Built with ❤️ by Adijaya
